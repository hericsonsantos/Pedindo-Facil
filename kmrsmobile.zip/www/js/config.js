
var krms_config ={	
	'ApiUrl' : "http://pedindofacil.com/mobileapp/api",
	'DialogDefaultTitle' : "YOUR_OWN_DIALOG_TITLE",
	'pushNotificationSenderid' : "YOUR_ANDROID_PUSH_PROJECT_ID",
	'facebookAppId' : "YOUR_FACEBOOK_APP_ID",
	'APIHasKey' : "72bc1a180e3986b3c362469972f6189c"
};
